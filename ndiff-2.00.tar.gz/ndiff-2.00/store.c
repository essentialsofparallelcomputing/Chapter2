#include "ndiff.h"

void
store(fp_t *x)
{

}
